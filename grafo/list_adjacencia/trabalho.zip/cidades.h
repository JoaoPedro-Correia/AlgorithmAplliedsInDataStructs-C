#ifndef CIDADES_H
#define CIDADES_H
enum cidades_conectadas {
  Oradea = 1,
  Zerind,
  Arad,
  Timisoara,
  Lugoj,
  Meehadia,
  Drobeta,
  Sibiu,
  Rimnicu_Vilcea,
  Craiova,
  Fagaras,
  Pitesti,
  Bucharest,
  Giurgiu,
  Neamt,
  Iasi,
  Vaslui,
  Urziceni,
  Hirsova,
  Eforie
};
#endif
