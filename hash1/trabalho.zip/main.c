/*PRE-PROCESSAMENTO DAS FUNCOES IMPORTADAS*/
#ifndef STDIO_H
#define STDIO_H
#include <stdio.h>
#endif

#ifndef STDLIB_H
#define STDLIB_H
#include <stdlib.h>
#endif

/*CHAMO A BIBLIOTECA DA LISTA*/
#include "list.h"

// DEFINE O TAMANHO DO ARRAY DA TABELA HASH
#define TAM 15

/*LIMPO O TERMINAL*/
void clear_window(void);
/*LIMPO O BUFFER DO COMPUTADOR*/
void clear_buff(void);
/*CALCULA O */
int hash_calculate(int);
/*EXIBE O MENU PRINCIPAL*/
int menu(void);
/*ADICIONA ALGUM NUMERO NA LISTA*/
void add_element(List *);
/*REMOVE ALGUM NUMERO DA LISTA*/
void remove_element(List *);
/*EXIBE A LISTA NA TELA*/
void print_list(List *);
/*PROCURA ALGUM NUMERO NA LISTA*/
void search_element(List *);

int main() {
  int option;
  List *list;

  /*CRIA UMA LISTA*/
  list = list_new_vector(TAM);

  // LUPIM DO PROGRAMA
  // SAI COM A OPCAO '0'
  do {
    /*LIMPA O TERMINAL*/
    clear_window();
    // EXIBE O MENU
    option = menu();

    // CHAMA A FUNCAO SELECIONADA PELO USUARIO
    switch (option) {
    case 1:
      add_element(list);
      getchar();
      break;
    case 2:
      remove_element(list);
      getchar();
      break;
    case 3:
      print_list(list);
      getchar();
      break;
    case 4:
      search_element(list);
      getchar();
      break;
    }
    // LIMPA O BUFFER
    clear_buff();
  } while (option != 0);

  /*DESALOCO TODO ARRAY E SEUS ALEMENTOS*/
  list_clear_vector(list, TAM);
  return 0;
}

void clear_buff() {
  int c;
  while ((c = getchar()) != '\n') {
  }
}

void clear_window() {
  // PRE-PROCESSAMENTO DO SO
#ifdef __linux__ // SE FOR LINUX
  system("clear");
#else // SE FOR WINDOWS
  system("cls");
#endif
}

int menu() {
  int option;
  printf("1 - Inserir\n");
  printf("2 - Remover\n");
  printf("3 - Printar listas\n");
  printf("4 - Buscas elemento\n");
  printf("0 - Sair\n");

  printf("\nOption: ");
  scanf("%d", &option);

  return option;
}

/*CALCULA O HAS COM BASE NO TAMANHO DO VETOR
 * QUE E DEIFINIDO COM O PRE-PROCESSAMENTO DO -> TAM*/
int hash_calculate(int n) { return n % TAM; }

void add_element(List *list) {
  int num;

  printf("\nAdicionar número: ");
  scanf("%d", &num);

  int i = hash_calculate(num); /*CALCULO O HASH DO INDICE DO ARRAY*/
  list_add(&list[i], num);
}

void remove_element(List *list) {
  int num;
  printf("\nRemover número: ");
  scanf("%d", &num);

  int i = hash_calculate(num); /*ACHA O HASH*/
  int r = list_remove(&list[i], num);

  if (r == 1) { // REMOVEU O NUMERO
    printf("\nRemovido com sucesso!\n");
  } else { // NAO TEM O NUMERO NA LISTA
    printf("\nLista não tem o valor\n");
  }
}

void print_list(List *list) {
  int i; // CONTADOR

  printf("\n\n==========LISTA=============\n");
  for (i = 0; i < TAM; i++) { // ANDO PELO ARRAY
    printf("(%d) -> ", i);    // EXIBE O INDICE DO ARRAY
    list_print(&list[i]);     // EXIBE A LISTA DO INDICE i
  }
}

void search_element(List *list) {
  int num;
  printf("\nBuscar número: ");
  scanf("%d", &num);

  int i = hash_calculate(num);
  int s = list_search_element(&list[i], num);

  if (s == 1) { // ACHOU O VALOR
    printf("\nAchou o valor!\n");
    printf("(%d) -> ", i); // EXIBE O INDICE DO ARRAY
    list_print(&list[i]);  // EXIBE A LISTA DO INDICE i
  } else {                 // NAO ACHOU O VALOR
    printf("\nNão achou o elemento\n");
  }
}
